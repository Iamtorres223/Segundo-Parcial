﻿#include <iostream>
#include <fstream>
#include <vector>
#include <string>

using namespace std;

struct Pos {
    int x, y;
};

bool dfs(vector<string>& maze, vector<vector<bool>>& visited, Pos current, Pos end) {
    if (current.x == end.x && current.y == end.y)
        return true;

    int dx[] = {-1, 1, 0, 0}; // arriba, abajo, izquierda, derecha
    int dy[] = {0, 0, -1, 1};

    visited[current.x][current.y] = true;

    for (int i = 0; i < 4; ++i) {
        int nx = current.x + dx[i];
        int ny = current.y + dy[i];

        if (nx >= 0 && nx < maze.size() && ny >= 0 && ny < maze[0].size() &&
            !visited[nx][ny] && (maze[nx][ny] == ' ' || maze[nx][ny] == 'E')) {

            if (dfs(maze, visited, {nx, ny}, end)) {
                if (maze[nx][ny] != 'E') maze[nx][ny] = 'X';
                return true;
            }
        }
    }

    return false;
}

int main() {
    ifstream infile("laberinto.txt");
    ofstream outfile("solucion.txt");

    if (!infile) {
        cerr << "No se pudo abrir el archivo de entrada." << endl;
        return 1;
    }

    vector<string> maze;
    string line;
    while (getline(infile, line)) {
        maze.push_back(line);
    }

    Pos start, end;
    bool foundStart = false, foundEnd = false;

    for (int i = 0; i < maze.size(); ++i) {
        for (int j = 0; j < maze[i].size(); ++j) {
            if (maze[i][j] == 'S') {
                start = {i, j};
                foundStart = true;
            }
            if (maze[i][j] == 'E') {
                end = {i, j};
                foundEnd = true;
            }
        }
    }

    if (!foundStart || !foundEnd) {
        cerr << "No se encontró el punto de inicio o fin en el laberinto." << endl;
        return 1;
    }

    vector<vector<bool>> visited(maze.size(), vector<bool>(maze[0].size(), false));
    dfs(maze, visited, start, end);

    for (const auto& row : maze) {
        outfile << row << endl;
    }

    cout << "Camino encontrado y guardado en 'solucion.txt'" << endl;
    return 0;
}